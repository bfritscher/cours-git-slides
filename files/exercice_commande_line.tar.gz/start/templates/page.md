---
title: sample post
author: name
date: YYYY-MM-DD HH:MM:S
tags:
---

# sample post

Some text

- [ ] item 1
- [x] item 2

