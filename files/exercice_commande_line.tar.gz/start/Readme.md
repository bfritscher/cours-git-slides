# Préparation du site

- Afficher le contenu du dossier `templates`.
- Créer un nouveau répertoire `pages`,
- dans lequel on place une copie du fichier template `page.md` avec comme nom `home.md`.
- Créer un nouveau répertoire `_data`,
- dans lequel il faut déplacer le fichier `contacts.csv`
- Ajouter votre `nom,prénom,email` dans le fichier contacts.csv
- Supprimer le fichier `password.txt`
